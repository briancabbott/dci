# create-licenses

This file is intended to be included with the `libs.zip` file that is
distributed with each `kpt` release. The `libs.zip` file contains a packaging of
source files necessary to satisfy the Mozilla license.
