// Package fromproto6 contains functions to convert from protocol version 6
// (tfprotov6) types to framework types.
package fromproto6
