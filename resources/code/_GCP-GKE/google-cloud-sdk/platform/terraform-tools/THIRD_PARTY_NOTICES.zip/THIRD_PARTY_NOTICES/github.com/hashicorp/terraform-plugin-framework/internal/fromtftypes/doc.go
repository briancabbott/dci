// Package fromtftypes contains functions to convert from terraform-plugin-go
// tftypes types to framework types.
package fromtftypes
