// Package xattr contains additional interfaces for attr types. This package
// is separate from the core attr package to prevent import cycles.
package xattr
