package types

import "github.com/hashicorp/terraform-plugin-framework/types/basetypes"

var Int64Type = basetypes.Int64Type{}
