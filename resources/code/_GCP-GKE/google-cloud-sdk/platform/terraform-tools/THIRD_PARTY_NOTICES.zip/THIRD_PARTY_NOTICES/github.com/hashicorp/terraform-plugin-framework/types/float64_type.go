package types

import "github.com/hashicorp/terraform-plugin-framework/types/basetypes"

var Float64Type = basetypes.Float64Type{}
