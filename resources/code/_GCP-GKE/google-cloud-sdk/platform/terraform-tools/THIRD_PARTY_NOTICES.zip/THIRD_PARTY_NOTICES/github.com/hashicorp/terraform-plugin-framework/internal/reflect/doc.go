// Package reflect contains the implementation for converting framework-defined
// data into and from provider-defined Go types.
package reflect
