// Package proto5server contains the provider server implementation compatible
// with protocol version 5 (tfprotov5.ProviderServer).
package proto5server
