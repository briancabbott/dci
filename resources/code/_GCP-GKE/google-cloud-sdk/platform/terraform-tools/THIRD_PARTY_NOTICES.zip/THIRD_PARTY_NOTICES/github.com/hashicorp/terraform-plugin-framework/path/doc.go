// Package path implements attribute path functionality, which defines
// transversals into schema-based data.
package path
