// Package tfsdk contains core framework functionality for schema data.
package tfsdk
