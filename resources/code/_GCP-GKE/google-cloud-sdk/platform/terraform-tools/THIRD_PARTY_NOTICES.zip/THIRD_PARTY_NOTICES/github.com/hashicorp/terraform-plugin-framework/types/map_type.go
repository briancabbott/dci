package types

import "github.com/hashicorp/terraform-plugin-framework/types/basetypes"

type MapType = basetypes.MapType
