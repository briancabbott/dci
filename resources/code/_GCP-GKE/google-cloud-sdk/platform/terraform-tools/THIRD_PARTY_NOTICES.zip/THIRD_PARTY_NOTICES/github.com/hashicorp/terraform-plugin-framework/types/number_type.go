package types

import "github.com/hashicorp/terraform-plugin-framework/types/basetypes"

var NumberType = basetypes.NumberType{}
