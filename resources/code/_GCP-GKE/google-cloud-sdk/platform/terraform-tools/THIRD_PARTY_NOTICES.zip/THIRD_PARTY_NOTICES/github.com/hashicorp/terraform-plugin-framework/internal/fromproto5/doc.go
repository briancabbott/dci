// Package fromproto5 contains functions to convert from protocol version 5
// (tfprotov5) types to framework types.
package fromproto5
