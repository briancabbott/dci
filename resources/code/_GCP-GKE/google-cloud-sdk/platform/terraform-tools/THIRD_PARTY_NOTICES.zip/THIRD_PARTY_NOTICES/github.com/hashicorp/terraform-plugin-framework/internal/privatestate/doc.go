// Package privatestate contains the type used for handling private resource
// state data.
package privatestate
