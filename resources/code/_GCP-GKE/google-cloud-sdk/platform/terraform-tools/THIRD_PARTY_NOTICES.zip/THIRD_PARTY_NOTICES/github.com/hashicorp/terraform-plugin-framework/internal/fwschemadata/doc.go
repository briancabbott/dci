// Package fwschemadata implements the shared schema-based data implementation
// for configuration, plan, and state values.
package fwschemadata
