package schema

type Key string

var (
	StopContextKey = Key("StopContext")
)
