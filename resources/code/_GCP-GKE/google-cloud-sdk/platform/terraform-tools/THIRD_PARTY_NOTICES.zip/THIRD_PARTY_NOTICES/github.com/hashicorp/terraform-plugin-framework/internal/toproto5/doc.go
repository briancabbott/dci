// Package toproto5 contains functions to convert from framework types to
// protocol version 5 (tfprotov5) types.
package toproto5
