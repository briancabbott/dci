// Package logging contains framework internal helpers for consistent logger
// and log entry handling.
package logging
