// Package attr contains type and value interfaces for core framework and
// provider-defined data types. The underlying xattr package contains
// additional interfaces for advanced type functionality.
package attr
