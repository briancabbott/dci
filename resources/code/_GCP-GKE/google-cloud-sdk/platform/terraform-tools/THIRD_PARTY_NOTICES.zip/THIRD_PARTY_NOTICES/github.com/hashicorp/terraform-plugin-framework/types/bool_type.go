package types

import "github.com/hashicorp/terraform-plugin-framework/types/basetypes"

var BoolType = basetypes.BoolType{}
