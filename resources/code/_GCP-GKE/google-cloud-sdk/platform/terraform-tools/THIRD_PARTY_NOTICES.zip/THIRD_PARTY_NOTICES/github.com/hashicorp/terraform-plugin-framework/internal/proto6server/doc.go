// Package proto6server contains the provider server implementation compatible
// with protocol version 6 (tfprotov6.ProviderServer).
package proto6server
