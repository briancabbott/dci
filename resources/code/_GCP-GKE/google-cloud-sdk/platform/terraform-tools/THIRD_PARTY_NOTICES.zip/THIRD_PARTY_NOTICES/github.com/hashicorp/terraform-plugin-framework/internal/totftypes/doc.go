// Package totftypes contains functions to convert from framework types to
// terraform-plugin-go tftypes types.
package totftypes
